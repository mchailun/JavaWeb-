-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: homework
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `administrator`
--

DROP TABLE IF EXISTS `administrator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `administrator` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administrator`
--

LOCK TABLES `administrator` WRITE;
/*!40000 ALTER TABLE `administrator` DISABLE KEYS */;
INSERT INTO `administrator` VALUES (1,'admin','admin');
/*!40000 ALTER TABLE `administrator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `book`
--

DROP TABLE IF EXISTS `book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `book` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Bno` varchar(30) NOT NULL,
  `Bname` varchar(30) DEFAULT NULL,
  `Bauthor` varchar(30) DEFAULT NULL,
  `Bprice` double(5,2) DEFAULT NULL,
  `Bnum` int DEFAULT NULL,
  `Bshelf` varchar(30) DEFAULT NULL,
  `Bremark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Bshelf` (`Bshelf`),
  KEY `Bno` (`Bno`),
  CONSTRAINT `Bshelf` FOREIGN KEY (`Bshelf`) REFERENCES `bookshelf` (`no`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book`
--

LOCK TABLES `book` WRITE;
/*!40000 ALTER TABLE `book` DISABLE KEYS */;
INSERT INTO `book` VALUES (1,'1001','高等数学','同济大学',100.50,0,'x101','由同济大学数学系编写、高等教育出版社出版的“十二五”普通高等教育本科国家级规划教材'),(2,'1002','线性代数','同济大学',124.00,1,'x101','由同济大学数学系编著、高等教育出版社出版社的“十二五”普通高等教育本科国家级规划教材'),(4,'1003','骆驼祥子','老舍',55.00,3,'x102','老舍（舒庆春，1899-1966）所著的长篇小说，描述了20世纪20年代军阀混战时期人力车夫的悲惨命运'),(5,'1004','都柏林人','詹姆斯·乔伊斯',56.00,5,'x102','爱尔兰作家詹姆斯·乔伊斯久负盛名的短篇小说集，总是在最细微的日常现实中发现人生的深意'),(6,'1005','卡夫卡短篇小说集','弗兰茨·卡夫卡',42.00,0,'x102','奥地利小说家弗兰茨·卡夫卡的经典短篇小说集，揭示着生命及周围世界的真相，展现了现代人生活的虚无、荒谬和孤独'),(7,'1006','莫泊桑短篇小说集','莫泊桑',33.00,3,'x102','法国作家、“短篇小说之王”莫泊桑的短篇小说集，展现了作者对不同人物及社会现实的理解和思考'),(8,'1007','梦的解析','弗洛伊德',56.50,0,'x103','本书主要就是通过对人们梦境的分析，了解人们内心深处的潜意识和真正的想法'),(9,'1008','幻想即现实','曾奇峰',39.00,0,'x103','专门研究精神分析，本书不仅有一定的科学依据，并且文字感染力比较强，读起来风趣幽默'),(10,'1009','中国哲学史','冯友兰',45.00,2,'x104','第一部完整的具有现代意义的中国哲学史'),(11,'1010','纯粹理性批判','康德',56.30,2,'x104','康德的三大批判著作之一，改变了西方哲学前进发展的方向和进程'),(12,'1011','理想国','柏拉图',35.50,3,'x104','柏拉图已苏格拉底之口通过与他人对话设计了一个真善美统一的整体，既可以达到公正的理想国'),(13,'1012','形而上学','亚里士多德',46.00,0,'x104','叙述了亚里士多德自己的哲学体系，成为许多西方哲学家获取灵感的源泉之一'),(14,'1013','人性论','休谟',36.00,0,'x104','休谟一生中最重要的著作，对于人类思想史具有独创性的理论贡献'),(15,'1014','都柏林人','詹姆斯·乔伊斯',56.00,6,'x102','爱尔兰作家詹姆斯·乔伊斯久负盛名的短篇小说集，总是在最细微的日常现实中发现人生的深意'),(16,'1015','领导力21法则','麦克斯维尔',74.00,5,'x1008','以21条清晰的法则，有效讲透了提升领导力的方方面面，将抽象的领导力概念以具象的方式呈现'),(17,'1016','从优秀到卓越','柯林斯',89.00,4,'x1008','描绘了优秀公司实现向卓越公司跨越的宏伟蓝图'),(18,'1017','有效的管理者','彼得·德鲁克',46.60,8,'x1008','1967年出版。集中论述了一个管理者如何才能做到卓有成效'),(19,'1018','竞争战略','迈克尔·波特',98.00,1,'x1008','此书中提出了行业结构分析模型，即\"五种竞争力模型\"'),(20,'1019','卓有成效的管理者','彼得·德鲁克',78.00,1,'x1008','如何卓有成效？记录并分析时间的使用情况，把眼光集中在贡献上，充分发挥人的长处，要事优先，有效决策');
/*!40000 ALTER TABLE `book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `book_appointment_relation`
--

DROP TABLE IF EXISTS `book_appointment_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `book_appointment_relation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Sno` int DEFAULT NULL,
  `Bno` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_appointment_Sno` (`Sno`),
  KEY `student_appointment_Bno` (`Bno`),
  CONSTRAINT `student_appointment_Bno` FOREIGN KEY (`Bno`) REFERENCES `book` (`Bno`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `student_appointment_Sno` FOREIGN KEY (`Sno`) REFERENCES `student` (`Sno`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book_appointment_relation`
--

LOCK TABLES `book_appointment_relation` WRITE;
/*!40000 ALTER TABLE `book_appointment_relation` DISABLE KEYS */;
INSERT INTO `book_appointment_relation` VALUES (16,2018212534,'1013'),(17,2018212534,'1012'),(19,2018212534,'1007'),(21,2018212564,'1007');
/*!40000 ALTER TABLE `book_appointment_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bookshelf`
--

DROP TABLE IF EXISTS `bookshelf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookshelf` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no` varchar(30) NOT NULL,
  `area` varchar(30) DEFAULT NULL,
  `location` varchar(30) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `no` (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookshelf`
--

LOCK TABLES `bookshelf` WRITE;
/*!40000 ALTER TABLE `bookshelf` DISABLE KEYS */;
INSERT INTO `bookshelf` VALUES (1,'x101','100','二楼西北角第一排','数学专业','数学资料'),(2,'x102','100','二楼西北角第二排','短篇小说','短篇小说'),(3,'x103','121','一楼东南角第二排','心理学','心理学'),(5,'x104','122','一楼东南角第一排','哲学理论','哲学'),(6,'x1008','165','三楼西北角第二排','管理学','管理学');
/*!40000 ALTER TABLE `bookshelf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `department` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Dno` varchar(30) NOT NULL,
  `Dname` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Dname` (`Dname`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` VALUES (1,'101','信息科学与工程学院'),(2,'102','农学院'),(3,'103','机械与电子工程学院'),(4,'104','外国语学院'),(5,'105','经济管理学院');
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `major`
--

DROP TABLE IF EXISTS `major`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `major` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Mno` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Mname` varchar(30) DEFAULT NULL,
  `Mdept` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Mname` (`Mname`),
  KEY `Mdept` (`Mdept`),
  CONSTRAINT `Mdept` FOREIGN KEY (`Mdept`) REFERENCES `department` (`Dname`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `major`
--

LOCK TABLES `major` WRITE;
/*!40000 ALTER TABLE `major` DISABLE KEYS */;
INSERT INTO `major` VALUES (1,'1','计算机科学与技术','信息科学与工程学院'),(2,'2','软件工程','信息科学与工程学院'),(3,'3','公共数学','信息科学与工程学院'),(4,'4','测绘科学与工程','信息科学与工程学院'),(5,'5','应用物理','信息科学与工程学院'),(6,'6','机械电子工程','信息科学与工程学院'),(7,'7','英语','外国语学院');
/*!40000 ALTER TABLE `major` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notice`
--

DROP TABLE IF EXISTS `notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sender` varchar(30) DEFAULT NULL,
  `receiver` varchar(30) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `time` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice`
--

LOCK TABLES `notice` WRITE;
/*!40000 ALTER TABLE `notice` DISABLE KEYS */;
INSERT INTO `notice` VALUES (52,'2018212534','admin','管理员你们好','2020-06-29'),(58,'2018212564','admin','管你元你，我是李','2020-06-29'),(64,'admin','2018212564','所有人都是啥B','2020-06-29'),(65,'admin','2018212599','所有人都是啥B','2020-06-29'),(66,'admin','2018212534','所有人都是啥B','2020-06-29'),(67,'2018212564','admin','狗管理我可以晚一点还钱吗，我是计算机八班的李子鬼','2020-06-29');
/*!40000 ALTER TABLE `notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Sno` int NOT NULL,
  `Sname` varchar(30) DEFAULT NULL,
  `Sage` int DEFAULT NULL,
  `Ssex` varchar(1) DEFAULT NULL,
  `Stel` varchar(30) DEFAULT NULL,
  `Smajor` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Smajor` (`Smajor`),
  KEY `Sno` (`Sno`),
  CONSTRAINT `Smajor` FOREIGN KEY (`Smajor`) REFERENCES `major` (`Mname`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES (2,2018212564,'李子鬼',77,'女','17866703601','计算机科学与技术'),(3,2018212501,'刘大键',19,'女','17866703601','英语'),(5,2018212599,'许三锋',55,'男','17866889933','公共数学'),(6,2018212534,'王晓雨',19,'男','17866703622','计算机科学与技术');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_book_relation`
--

DROP TABLE IF EXISTS `student_book_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_book_relation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Sno` int DEFAULT NULL,
  `Bno` varchar(30) DEFAULT NULL,
  `time` varchar(30) DEFAULT NULL,
  `renew` tinyint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_book_Sno` (`Sno`),
  KEY `student_book_Bno` (`Bno`),
  CONSTRAINT `student_book_Bno` FOREIGN KEY (`Bno`) REFERENCES `book` (`Bno`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `student_book_Sno` FOREIGN KEY (`Sno`) REFERENCES `student` (`Sno`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_book_relation`
--

LOCK TABLES `student_book_relation` WRITE;
/*!40000 ALTER TABLE `student_book_relation` DISABLE KEYS */;
INSERT INTO `student_book_relation` VALUES (140,2018212534,'1001','2020-06-29',0),(148,2018212564,'1001','2020-06-30',0),(149,2018212564,'1003','2020-06-30',0),(150,2018212564,'1004','2020-06-30',0),(151,2018212564,'1006','2020-06-30',0),(152,2018212564,'1011','2020-06-30',0),(153,2018212564,'1017','2020-06-30',1),(154,2018212564,'1018','2020-06-30',0);
/*!40000 ALTER TABLE `student_book_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_borrow_relation`
--

DROP TABLE IF EXISTS `student_borrow_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_borrow_relation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Sno` int DEFAULT NULL,
  `num` int DEFAULT NULL,
  `state` tinyint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_borrow_relation` (`Sno`),
  CONSTRAINT `student_borrow_relation` FOREIGN KEY (`Sno`) REFERENCES `student` (`Sno`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_borrow_relation`
--

LOCK TABLES `student_borrow_relation` WRITE;
/*!40000 ALTER TABLE `student_borrow_relation` DISABLE KEYS */;
INSERT INTO `student_borrow_relation` VALUES (1,2018212564,7,1),(3,2018212534,1,1);
/*!40000 ALTER TABLE `student_borrow_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_fine_relation`
--

DROP TABLE IF EXISTS `student_fine_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_fine_relation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Sno` int DEFAULT NULL,
  `money` double(5,1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_fine_Sno` (`Sno`),
  CONSTRAINT `student_fine_Sno` FOREIGN KEY (`Sno`) REFERENCES `student` (`Sno`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_fine_relation`
--

LOCK TABLES `student_fine_relation` WRITE;
/*!40000 ALTER TABLE `student_fine_relation` DISABLE KEYS */;
INSERT INTO `student_fine_relation` VALUES (2,2018212564,99.0),(3,2018212534,0.0);
/*!40000 ALTER TABLE `student_fine_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Sno` int DEFAULT NULL,
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Sno` (`Sno`),
  CONSTRAINT `Sno` FOREIGN KEY (`Sno`) REFERENCES `student` (`Sno`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (2,2018212564,'ghost','ghost'),(6,2018212534,'wang12345','12345');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-30 20:28:46
